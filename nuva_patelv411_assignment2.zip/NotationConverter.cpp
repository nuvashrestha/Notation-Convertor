// Vaibhavi Patel and Nuva Shrestha
#include "NotationConverter.hpp" // Including the header file for NotationConverterInterface
#include "Deque.hpp"             // Including the header file for Deque (Double-ended queue)
#include <stdexcept>             // Including the header file for standard exception types

inline int precedence(char val) // Function to determine precedence of operators
{
    if (val == '+' || val == '-') // If operator is addition or subtraction, return 1
    {
        return 1;
    }
    else if (val == '*' || val == '/') // If operator is multiplication or division, return 2
    {
        return 2;
    }
    else // For any other character, return 0
    {
        return 0;
    }
}

class NotationConverter : public NotationConverterInterface // Class definition for NotationConverter implementing NotationConverterInterface
{
public:
    std::string postfixToInfix(std::string inStr) override
    {
        DequeDLL expressionDeque;                 // Creating an instance of the Deque class
        for (size_t i = 0; i < inStr.size(); i++) // Loop through the input string
        {
            char ch = inStr[i]; // Get the current character
            if (ch == ' ')      // If it's a space, continue to the next character
            {
                continue;
            }
            if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')) // If it's an alphabet
            {
                std::string operand(1, ch);        // Convert the character to a string
                expressionDeque.pushBack(operand); // Push it to the back of the deque
            }
            else if (ch == '+' || ch == '-' || ch == '*' || ch == '/') // If it's an operator
            {
                std::string operand2 = " " + expressionDeque.back();                // Get the second operand
                expressionDeque.popBack();                                          // Pop it from the deque
                std::string operand1 = expressionDeque.back() + " ";                // Get the first operand
                expressionDeque.popBack();                                          // Pop it from the deque
                std::string infixExpression = "(" + operand1 + ch + operand2 + ")"; // Create the infix expression with operands and operator
                expressionDeque.pushBack(infixExpression);                          // Push the infix expression to the deque
            }
        }
        return expressionDeque.back(); // Return the resulting infix expression
    }

    std::string postfixToPrefix(std::string inStr) override
    {
        DequeDLL expressionDeque;                 // Creating an instance of the Deque class
        for (size_t i = 0; i < inStr.size(); i++) // Loop through the input string
        {
            char ch = inStr[i]; // Get the current character
            if (ch == ' ')      // If it's a space, continue to the next character
            {
                continue;
            }
            if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')) // If it's an alphabet
            {
                std::string operand(1, ch);         // Convert the character to a string
                expressionDeque.pushFront(operand); // Push it to the front of the deque
            }
            else if (ch == '+' || ch == '-' || ch == '*' || ch == '/') // If it's an operator
            {
                std::string operand2 = " " + expressionDeque.front();    // Get the second operand
                expressionDeque.popFront();                              // Pop it from the deque
                std::string operand1 = " " + expressionDeque.front();    // Get the first operand
                expressionDeque.popFront();                              // Pop it from the deque
                std::string prefixExpression = ch + operand1 + operand2; // Create the prefix expression with operands and operator
                expressionDeque.pushFront(prefixExpression);             // Push the prefix expression to the deque
            }
        }
        return expressionDeque.front(); // Return the resulting prefix expression
    }

    std::string infixToPostfix(std::string inStr) override
    {
        DequeDLL expressionDeque; // Creating an instance of the Deque class
        std::string postfix;      // Initialize an empty string for the resulting postfix expression
        for (char ch : inStr)     // Loop through each character in the input string
        {
            if (ch == ' ') // If it's a space, continue to the next character
                continue;
            if (((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z'))) // If it's an alphabet
            {
                postfix += ch;  // Append it to the postfix expression
                postfix += " "; // Add a space after the operand
            }
            else if (ch == '(') // If it's an opening parenthesis
            {
                expressionDeque.pushFront(std::string(1, ch)); // Push it to the front of the deque
            }
            else if (ch == ')') // If it's a closing parenthesis
            {
                while (!expressionDeque.empty() && expressionDeque.front() != "(") // Until an opening parenthesis is encountered
                {
                    postfix += expressionDeque.front(); // Append the front element of the deque to the postfix expression
                    postfix += " ";                     // Add a space
                    expressionDeque.popFront();         // Pop the front element from the deque
                }

                if (!expressionDeque.empty() && expressionDeque.back() == "(")
                    expressionDeque.popFront(); // Remove the opening parenthesis from deque
            }
            else if (ch == '+' || ch == '-' || ch == '*' || ch == '/') // If it's an operator
            {
                while (!expressionDeque.empty() && precedence(ch) <= precedence(expressionDeque.front()[0]))
                {
                    postfix += expressionDeque.front(); // Append the front element of the deque to the postfix expression
                    expressionDeque.popFront();         // Pop the front element from the deque
                    postfix += " ";                     // Add a space
                }
                expressionDeque.pushFront(std::string(1, ch)); // Push current operator to deque
            }
        }

        while (!expressionDeque.empty()) // After processing all characters
        {
            postfix += expressionDeque.front(); // Append the remaining elements of the deque to the postfix expression
            expressionDeque.popFront();         // Pop the front element from the deque
            postfix += " ";                     // Add a space
        }

        return postfix; // Return the resulting postfix expression
    }

    std::string infixToPrefix(std::string inStr) override
    {
        DequeDLL expressionDeque; // Creating an instance of the Deque class
        std::string prefix = "";  // Initialize an empty string for the resulting prefix expression
        bool firstOperand = true; // Flag to indicate if it's the first operand

        for (int i = inStr.size() - 1; i >= 0; i--) // Loop through the input string in reverse
        {
            char ch = inStr[i]; // Get the current character
            if (ch == ' ')      // If it's a space, continue to the next character
            {
                continue;
            }
            if (((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z'))) // If it's an alphabet
            {
                if (!firstOperand) // If it's not the first operand
                {
                    prefix = " " + prefix; // Add a space before appending the operand
                }
                prefix = ch + prefix; // Append the operand to the prefix expression
                firstOperand = false; // Set the flag to false after the first operand
            }
            else if (ch == ')') // If it's a closing parenthesis
            {
                expressionDeque.pushFront(std::string(1, ch)); // Push it to the front of the deque
            }
            else if (ch == '(') // If it's an opening parenthesis
            {
                while (!expressionDeque.empty() && expressionDeque.front()[0] != ')') // Until a closing parenthesis is encountered
                {
                    prefix = expressionDeque.front() + " " + prefix; // Append the front element of the deque to the prefix expression
                    expressionDeque.popFront();                      // Pop the front element from the deque
                }
                expressionDeque.popFront(); // Remove the closing parenthesis from deque
            }
            else if (ch == '+' || ch == '-' || ch == '*' || ch == '/') // If it's an operator
            {
                while (!expressionDeque.empty() && precedence(ch) <= precedence(expressionDeque.front()[0]))
                {
                    prefix = expressionDeque.front() + prefix; // Append the front element of the deque to the prefix expression
                    expressionDeque.popFront();                // Pop the front element from the deque
                }
                expressionDeque.pushFront(std::string(1, ch)); // Push current operator to deque
            }
        }
        while (!expressionDeque.empty()) // After processing all characters
        {
            prefix = expressionDeque.front() + prefix; // Append the remaining elements of the deque to the prefix expression
            expressionDeque.popFront();                // Pop the front element from the deque
        }
        return prefix; // Return the resulting prefix expression
    }

    std::string prefixToInfix(std::string inStr) override
    {
        DequeDLL expressionDeque;                   // Creating an instance of the Deque class
        for (int i = inStr.size() - 1; i >= 0; i--) // Loop through the input string in reverse
        {
            char ch = inStr[i]; // Get the current character
            if (ch == ' ')      // If it's a space, continue to the next character
                continue;
            if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')) // If it's an alphabet
            {
                std::string operand(1, ch);         // Convert the character to a string
                expressionDeque.pushFront(operand); // Push it to the front of the deque
            }
            else if (ch == '+' || ch == '-' || ch == '*' || ch == '/') // If it's an operator
            {
                std::string operand1 = expressionDeque.front() + " ";               // Get the first operand
                expressionDeque.popFront();                                         // Pop it from the deque
                std::string operand2 = " " + expressionDeque.front();               // Get the second operand
                expressionDeque.popFront();                                         // Pop it from the deque
                std::string infixExpression = "(" + operand1 + ch + operand2 + ")"; // Create the infix expression with operands and operator
                expressionDeque.pushFront(infixExpression);                         // Push the infix expression to the deque
            }
        }
        return expressionDeque.front(); // Return the resulting infix expression
    }

    std::string prefixToPostfix(std::string inStr) override
    {
        DequeDLL expressionDeque;                   // Creating an instance of the Deque class
        for (int i = inStr.size() - 1; i >= 0; i--) // Loop through the input string in reverse
        {
            char ch = inStr[i]; // Get the current character
            if (ch == ' ')      // If it's a space, continue to the next character
            {
                continue;
            }
            if (((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z'))) // If it's an alphabet
            {
                std::string operand(1, ch);         // Convert the character to a string
                expressionDeque.pushFront(operand); // Push it to the front of the deque
            }
            else if (ch == '+' || ch == '-' || ch == '*' || ch == '/') // If it's an operator
            {
                std::string operand2 = expressionDeque.front() + " ";     // Get the second operand
                expressionDeque.popFront();                               // Pop it from the deque
                std::string operand1 = expressionDeque.front() + " ";     // Get the first operand
                expressionDeque.popFront();                               // Pop it from the deque
                std::string expressionPostfix = operand2 + operand1 + ch; // Create the postfix expression
                expressionDeque.pushFront(expressionPostfix);             // Push the postfix expression to the deque
            }
        }
        return expressionDeque.front(); // Return the resulting postfix expression
    }
};